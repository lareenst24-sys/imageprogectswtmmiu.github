import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Loader2, CheckCircle } from "lucide-react";

interface AdWatchModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function AdWatchModal({ open, onOpenChange }: AdWatchModalProps) {
  const [isWatching, setIsWatching] = useState(false);
  const [adDuration, setAdDuration] = useState(30);
  const [completed, setCompleted] = useState(false);

  const watchAdMutation = trpc.adWatch.watch.useMutation({
    onSuccess: (data) => {
      setCompleted(true);
      toast.success(data.message);
      // Invalidate queries to refresh the dashboard
      setTimeout(() => {
        trpc.useUtils().uploadLimit.status.invalidate();
        trpc.useUtils().adWatch.remainingToday.invalidate();
        onOpenChange(false);
        setCompleted(false);
        setIsWatching(false);
        setAdDuration(30);
      }, 2000);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to watch ad");
      setIsWatching(false);
    },
  });

  useEffect(() => {
    if (!isWatching || adDuration <= 0) return;

    const timer = setInterval(() => {
      setAdDuration((prev) => {
        if (prev <= 1) {
          setIsWatching(false);
          watchAdMutation.mutate();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isWatching, adDuration, watchAdMutation]);

  const handleClose = () => {
    if (!isWatching && !completed) {
      onOpenChange(false);
      setAdDuration(30);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="bg-black border-purple-900/50 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-purple-400">Watch Ad for Bonus Uploads</DialogTitle>
          <DialogDescription className="text-gray-400">
            Watch a short advertisement to earn 100 bonus image uploads
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {completed ? (
            <div className="text-center py-8">
              <CheckCircle className="mx-auto text-green-500 mb-4" size={64} />
              <h3 className="text-xl font-bold mb-2">Success!</h3>
              <p className="text-gray-400 mb-4">
                You've earned 100 bonus image uploads
              </p>
              <p className="text-sm text-gray-500">
                Redirecting to dashboard...
              </p>
            </div>
          ) : isWatching ? (
            <div className="text-center py-8">
              <div className="mb-6">
                <div className="bg-purple-900/30 border border-purple-900/50 rounded-lg p-8 mb-4">
                  <p className="text-gray-400 mb-2">Ad playing...</p>
                  <div className="text-5xl font-bold text-purple-400">
                    {adDuration}
                  </div>
                  <p className="text-sm text-gray-500 mt-2">seconds remaining</p>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-purple-900/30 rounded-full h-2 border border-purple-900/50 mb-4">
                <div
                  className="bg-gradient-to-r from-purple-500 to-purple-700 h-2 rounded-full transition-all"
                  style={{
                    width: `${((30 - adDuration) / 30) * 100}%`,
                  }}
                />
              </div>

              <p className="text-sm text-gray-400">
                Please don't close this window
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-purple-900/20 border border-purple-900/50 rounded-lg p-6">
                <h3 className="font-semibold mb-3">What you'll get:</h3>
                <ul className="space-y-2 text-sm text-gray-300">
                  <li className="flex items-center">
                    <span className="text-purple-400 mr-2">✓</span>
                    100 bonus image uploads
                  </li>
                  <li className="flex items-center">
                    <span className="text-purple-400 mr-2">✓</span>
                    Valid for today only
                  </li>
                  <li className="flex items-center">
                    <span className="text-purple-400 mr-2">✓</span>
                    Watch up to 10 ads per day
                  </li>
                </ul>
              </div>

              <p className="text-xs text-gray-500">
                The ad will play for 30 seconds. Please watch it completely to earn your bonus.
              </p>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => onOpenChange(false)}
                  className="flex-1 border-purple-600 text-purple-400 hover:bg-purple-900/30"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => setIsWatching(true)}
                  className="flex-1 bg-purple-600 hover:bg-purple-700"
                >
                  Watch Ad
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

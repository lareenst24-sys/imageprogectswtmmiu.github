import { useState, useRef } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Upload, Loader2 } from "lucide-react";

interface ImageUploadModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function ImageUploadModal({ open, onOpenChange }: ImageUploadModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);

  const uploadMutation = trpc.images.upload.useMutation({
    onSuccess: () => {
      toast.success("Image uploaded successfully!");
      setSelectedFile(null);
      setPreview(null);
      onOpenChange(false);
      // Invalidate queries to refresh the gallery
      trpc.useUtils().images.list.invalidate();
      trpc.useUtils().uploadLimit.status.invalidate();
      trpc.useUtils().earnings.total.invalidate();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to upload image");
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast.error("Please select a valid image file");
      return;
    }

    // Validate file size (max 50MB)
    const maxSize = 50 * 1024 * 1024;
    if (file.size > maxSize) {
      toast.error("File size must be less than 50MB");
      return;
    }

    setSelectedFile(file);

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    const buffer = await selectedFile.arrayBuffer();
    uploadMutation.mutate({
      fileName: selectedFile.name,
      fileData: new Uint8Array(buffer) as any,
      mimeType: selectedFile.type,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-black border-purple-900/50 text-white">
        <DialogHeader>
          <DialogTitle className="text-purple-400">Upload Image</DialogTitle>
          <DialogDescription className="text-gray-400">
            Choose an image to upload and start earning
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* File Input Area */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-purple-900/50 rounded-lg p-8 text-center cursor-pointer hover:border-purple-700/50 transition bg-purple-900/10"
          >
            {preview ? (
              <div className="space-y-4">
                <img
                  src={preview}
                  alt="Preview"
                  className="max-h-48 mx-auto rounded"
                />
                <p className="text-sm text-gray-400">{selectedFile?.name}</p>
                <p className="text-xs text-gray-500">
                  {(selectedFile?.size || 0) / 1024 / 1024 < 1
                    ? `${((selectedFile?.size || 0) / 1024).toFixed(2)} KB`
                    : `${((selectedFile?.size || 0) / 1024 / 1024).toFixed(2)} MB`}
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                <Upload className="mx-auto text-purple-500" size={48} />
                <p className="font-semibold">Click to upload or drag and drop</p>
                <p className="text-sm text-gray-400">PNG, JPG, GIF up to 50MB</p>
              </div>
            )}
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
          />

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => {
                setSelectedFile(null);
                setPreview(null);
              }}
              className="flex-1 border-purple-600 text-purple-400 hover:bg-purple-900/30"
              disabled={uploadMutation.isPending}
            >
              Clear
            </Button>
            <Button
              onClick={handleUpload}
              disabled={!selectedFile || uploadMutation.isPending}
              className="flex-1 bg-purple-600 hover:bg-purple-700"
            >
              {uploadMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 animate-spin" size={20} />
                  Uploading...
                </>
              ) : (
                "Upload"
              )}
            </Button>
          </div>

          <p className="text-xs text-gray-500">
            You'll earn $0.01 for each image uploaded.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

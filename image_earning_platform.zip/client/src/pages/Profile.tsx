import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { ArrowLeft, LogOut } from "lucide-react";
import { useState } from "react";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const CURRENCIES = [
  { code: "USD", name: "US Dollar" },
  { code: "EUR", name: "Euro" },
  { code: "GBP", name: "British Pound" },
  { code: "JPY", name: "Japanese Yen" },
  { code: "CAD", name: "Canadian Dollar" },
  { code: "AUD", name: "Australian Dollar" },
  { code: "INR", name: "Indian Rupee" },
];

export default function Profile() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [selectedCurrency, setSelectedCurrency] = useState("USD");
  const [withdrawAmount, setWithdrawAmount] = useState("");

  // Fetch user settings
  const { data: settings, isLoading: settingsLoading } = trpc.settings.get.useQuery();
  const { data: payments, isLoading: paymentsLoading } = trpc.payments.list.useQuery({ limit: 10 });

  // Mutations
  const updateCurrencyMutation = trpc.settings.updateCurrency.useMutation({
    onSuccess: () => {
      toast.success("Currency updated successfully!");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update currency");
    },
  });

  const createWithdrawalMutation = trpc.payments.createWithdrawal.useMutation({
    onSuccess: () => {
      toast.success("Withdrawal initiated! Check your email for confirmation.");
      setWithdrawAmount("");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create withdrawal");
    },
  });

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  const handleCurrencyChange = (currency: string) => {
    setSelectedCurrency(currency);
    updateCurrencyMutation.mutate({ currency });
  };

  const handleWithdraw = () => {
    const amount = parseFloat(withdrawAmount);
    if (!amount || amount <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    if (amount > (settings?.totalEarnings || 0) - (settings?.totalWithdrawn || 0)) {
      toast.error("Insufficient funds");
      return;
    }

    // TODO: Integrate with Stripe payment method
    createWithdrawalMutation.mutate({
      amount,
      stripePaymentMethodId: "pm_test", // Placeholder
    });
  };

  if (settingsLoading || paymentsLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="animate-spin text-purple-500" size={48} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-purple-900/30 bg-black/50 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/dashboard")}
              className="text-purple-400 hover:text-purple-300"
            >
              <ArrowLeft size={20} />
            </Button>
            <div className="text-2xl font-bold bg-gradient-to-r from-purple-500 to-purple-700 bg-clip-text text-transparent">
              Profile Settings
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            className="text-purple-400 hover:text-purple-300"
          >
            <LogOut size={20} />
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* User Info */}
        <Card className="bg-gradient-to-br from-purple-900/30 to-black border-purple-900/50 p-6 mb-6">
          <h2 className="text-xl font-bold mb-4">Account Information</h2>
          <div className="space-y-3">
            <div>
              <p className="text-sm text-gray-400">Name</p>
              <p className="text-lg font-semibold">{user?.name || "N/A"}</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Email</p>
              <p className="text-lg font-semibold">{user?.email || "N/A"}</p>
            </div>
          </div>
        </Card>

        {/* Currency Selection */}
        <Card className="bg-gradient-to-br from-purple-900/30 to-black border-purple-900/50 p-6 mb-6">
          <h2 className="text-xl font-bold mb-4">Preferred Currency</h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-400 block mb-2">Select Currency</label>
              <Select value={selectedCurrency} onValueChange={handleCurrencyChange}>
                <SelectTrigger className="bg-black border-purple-900/50 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-black border-purple-900/50">
                  {CURRENCIES.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code} className="text-white">
                      {currency.code} - {currency.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <p className="text-sm text-gray-400">
              Your earnings and payments will be displayed in {selectedCurrency}.
            </p>
          </div>
        </Card>

        {/* Earnings & Withdrawal */}
        <Card className="bg-gradient-to-br from-purple-900/30 to-black border-purple-900/50 p-6 mb-6">
          <h2 className="text-xl font-bold mb-4">Earnings & Withdrawal</h2>
          <div className="grid md:grid-cols-3 gap-4 mb-6">
            <div className="bg-black/50 border border-purple-900/30 rounded p-4">
              <p className="text-sm text-gray-400 mb-2">Total Earnings</p>
              <p className="text-2xl font-bold text-purple-400">
                ${settings?.totalEarnings.toFixed(2) || "0.00"}
              </p>
            </div>
            <div className="bg-black/50 border border-purple-900/30 rounded p-4">
              <p className="text-sm text-gray-400 mb-2">Total Withdrawn</p>
              <p className="text-2xl font-bold text-purple-400">
                ${settings?.totalWithdrawn.toFixed(2) || "0.00"}
              </p>
            </div>
            <div className="bg-black/50 border border-purple-900/30 rounded p-4">
              <p className="text-sm text-gray-400 mb-2">Available Balance</p>
              <p className="text-2xl font-bold text-purple-400">
                ${((settings?.totalEarnings || 0) - (settings?.totalWithdrawn || 0)).toFixed(2)}
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-400 block mb-2">Withdrawal Amount ({selectedCurrency})</label>
              <input
                type="number"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                placeholder="Enter amount"
                className="w-full bg-black border border-purple-900/50 rounded px-4 py-2 text-white placeholder-gray-600 focus:border-purple-500 focus:outline-none"
              />
            </div>
            <Button
              onClick={handleWithdraw}
              disabled={createWithdrawalMutation.isPending || !withdrawAmount}
              className="w-full bg-purple-600 hover:bg-purple-700"
            >
              {createWithdrawalMutation.isPending ? "Processing..." : "Request Withdrawal"}
            </Button>
            <p className="text-xs text-gray-500">
              Minimum withdrawal: $1.00. Funds will be transferred to your bank account within 3-5 business days.
            </p>
          </div>
        </Card>

        {/* Payment History */}
        <Card className="bg-gradient-to-br from-purple-900/30 to-black border-purple-900/50 p-6">
          <h2 className="text-xl font-bold mb-4">Payment History</h2>
          {payments && payments.payments.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-purple-900/30">
                    <th className="text-left py-3 px-2 text-gray-400">Date</th>
                    <th className="text-left py-3 px-2 text-gray-400">Amount</th>
                    <th className="text-left py-3 px-2 text-gray-400">Type</th>
                    <th className="text-left py-3 px-2 text-gray-400">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {payments.payments.map((payment) => (
                    <tr key={payment.id} className="border-b border-purple-900/20 hover:bg-purple-900/10">
                      <td className="py-3 px-2">
                        {new Date(payment.createdAt).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-2 text-purple-400">
                        ${payment.amount.toFixed(2)} {payment.currency}
                      </td>
                      <td className="py-3 px-2 capitalize">{payment.type}</td>
                      <td className="py-3 px-2">
                        <span
                          className={`px-2 py-1 rounded text-xs font-semibold ${
                            payment.status === "completed"
                              ? "bg-green-900/30 text-green-400"
                              : payment.status === "pending"
                              ? "bg-yellow-900/30 text-yellow-400"
                              : "bg-red-900/30 text-red-400"
                          }`}
                        >
                          {payment.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-gray-400 text-center py-8">No payment history yet</p>
          )}
        </Card>
      </main>
    </div>
  );
}

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { ArrowRight, Upload, TrendingUp, Lock } from "lucide-react";
import { useEffect } from "react";

export default function Home() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (isAuthenticated) {
      navigate("/dashboard");
    }
  }, [isAuthenticated]);

  const loginUrl = getLoginUrl();

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="border-b border-purple-900/30 bg-black/50 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold bg-gradient-to-r from-purple-500 to-purple-700 bg-clip-text text-transparent">
            ImageEarn
          </div>
          <a href={loginUrl} className="inline-block">
            <Button className="bg-purple-600 hover:bg-purple-700">
              Sign In with Google
            </Button>
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-black pointer-events-none" />

        <div className="max-w-6xl mx-auto relative z-10">
          <div className="text-center mb-12">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-purple-400 via-purple-500 to-purple-600 bg-clip-text text-transparent">
              Earn Money by Sharing Images
            </h1>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Upload your images, reach a global audience, and earn real money. No limits, no hassles—just pure earning potential.
            </p>
            <a href={loginUrl} className="inline-block">
              <Button size="lg" className="bg-purple-600 hover:bg-purple-700 text-lg px-8 py-6">
                Get Started Free <ArrowRight className="ml-2" />
              </Button>
            </a>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-3 gap-8 mt-20">
            {/* Feature 1 */}
            <div className="bg-gradient-to-br from-purple-900/30 to-black border border-purple-900/50 rounded-lg p-8 hover:border-purple-700/50 transition">
              <div className="bg-purple-600/20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Upload className="text-purple-400" size={24} />
              </div>
              <h3 className="text-xl font-bold mb-3">Easy Upload</h3>
              <p className="text-gray-400">
                Upload up to 1,000 images per day. Watch ads to unlock unlimited uploads.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-gradient-to-br from-purple-900/30 to-black border border-purple-900/50 rounded-lg p-8 hover:border-purple-700/50 transition">
              <div className="bg-purple-600/20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="text-purple-400" size={24} />
              </div>
              <h3 className="text-xl font-bold mb-3">Instant Earnings</h3>
              <p className="text-gray-400">
                Earn $0.01 per image. Track your earnings in real-time on your dashboard.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-gradient-to-br from-purple-900/30 to-black border border-purple-900/50 rounded-lg p-8 hover:border-purple-700/50 transition">
              <div className="bg-purple-600/20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Lock className="text-purple-400" size={24} />
              </div>
              <h3 className="text-xl font-bold mb-3">Secure & Safe</h3>
              <p className="text-gray-400">
                Your data is protected with enterprise-grade security. Withdraw anytime.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gradient-to-r from-purple-900/20 to-black border-y border-purple-900/30 py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-purple-400 mb-2">50K+</div>
              <p className="text-gray-400">Active Users</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-purple-400 mb-2">$2M+</div>
              <p className="text-gray-400">Paid Out</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-purple-400 mb-2">100M+</div>
              <p className="text-gray-400">Images Uploaded</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Start Earning?</h2>
          <p className="text-gray-400 mb-8">
            Join thousands of creators earning money from their images every day.
          </p>
          <a href={loginUrl} className="inline-block">
            <Button size="lg" className="bg-purple-600 hover:bg-purple-700 text-lg px-8 py-6">
              Sign In with Google <ArrowRight className="ml-2" />
            </Button>
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-purple-900/30 bg-black/50 py-8 px-4">
        <div className="max-w-6xl mx-auto text-center text-gray-500 text-sm">
          <p>&copy; 2026 ImageEarn. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

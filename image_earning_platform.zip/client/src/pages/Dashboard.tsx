import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { LogOut, Settings, Upload as UploadIcon, TrendingUp, Image as ImageIcon } from "lucide-react";
import { useState } from "react";
import ImageUploadModal from "@/components/ImageUploadModal";
import AdWatchModal from "@/components/AdWatchModal";
import { Loader2 } from "lucide-react";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showAdModal, setShowAdModal] = useState(false);

  // Fetch dashboard data
  const { data: uploadStatus, isLoading: uploadLoading } = trpc.uploadLimit.status.useQuery();
  const { data: earnings, isLoading: earningsLoading } = trpc.earnings.total.useQuery();
  const { data: images, isLoading: imagesLoading } = trpc.images.list.useQuery({ limit: 12, offset: 0 });
  const { data: adRemaining } = trpc.adWatch.remainingToday.useQuery();

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  if (uploadLoading || earningsLoading || imagesLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="animate-spin text-purple-500" size={48} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-purple-900/30 bg-black/50 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold bg-gradient-to-r from-purple-500 to-purple-700 bg-clip-text text-transparent">
            ImageEarn
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-400">Welcome, {user?.name}</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/profile")}
              className="text-purple-400 hover:text-purple-300"
            >
              <Settings size={20} />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-purple-400 hover:text-purple-300"
            >
              <LogOut size={20} />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats Grid */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          {/* Images Uploaded */}
          <Card className="bg-gradient-to-br from-purple-900/30 to-black border-purple-900/50 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-2">Images Uploaded</p>
                <p className="text-3xl font-bold text-purple-400">{images?.totalCount || 0}</p>
              </div>
              <ImageIcon className="text-purple-500" size={32} />
            </div>
          </Card>

          {/* Today's Uploads */}
          <Card className="bg-gradient-to-br from-purple-900/30 to-black border-purple-900/50 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-2">Today's Uploads</p>
                <p className="text-3xl font-bold text-purple-400">
                  {uploadStatus?.imagesUploaded || 0}/{uploadStatus?.totalLimit || 1000}
                </p>
              </div>
              <UploadIcon className="text-purple-500" size={32} />
            </div>
          </Card>

          {/* Total Earnings */}
          <Card className="bg-gradient-to-br from-purple-900/30 to-black border-purple-900/50 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-2">Total Earnings</p>
                <p className="text-3xl font-bold text-purple-400">
                  ${earnings?.total.toFixed(2) || "0.00"}
                </p>
              </div>
              <TrendingUp className="text-purple-500" size={32} />
            </div>
          </Card>

          {/* Available Balance */}
          <Card className="bg-gradient-to-br from-purple-900/30 to-black border-purple-900/50 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-2">Available Balance</p>
                <p className="text-3xl font-bold text-purple-400">
                  ${earnings?.available.toFixed(2) || "0.00"}
                </p>
              </div>
              <TrendingUp className="text-purple-500" size={32} />
            </div>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4 mb-8">
          <Button
            onClick={() => setShowUploadModal(true)}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <UploadIcon className="mr-2" size={20} />
            Upload Image
          </Button>
          <Button
            onClick={() => setShowAdModal(true)}
            variant="outline"
            className="border-purple-600 text-purple-400 hover:bg-purple-900/30"
            disabled={!adRemaining || adRemaining.remaining === 0}
          >
            Watch Ad for Bonus ({adRemaining?.remaining || 0} remaining)
          </Button>
        </div>

        {/* Upload Limit Progress */}
        <Card className="bg-gradient-to-br from-purple-900/30 to-black border-purple-900/50 p-6 mb-8">
          <h3 className="text-lg font-bold mb-4">Daily Upload Limit</h3>
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-gray-400 mb-2">
              <span>
                {uploadStatus?.imagesUploaded || 0} / {uploadStatus?.totalLimit || 1000} images
              </span>
              <span>
                {((uploadStatus?.imagesUploaded || 0) / (uploadStatus?.totalLimit || 1000) * 100).toFixed(0)}%
              </span>
            </div>
            <div className="w-full bg-purple-900/30 rounded-full h-2 border border-purple-900/50">
              <div
                className="bg-gradient-to-r from-purple-500 to-purple-700 h-2 rounded-full transition-all"
                style={{
                  width: `${((uploadStatus?.imagesUploaded || 0) / (uploadStatus?.totalLimit || 1000) * 100)}%`,
                }}
              />
            </div>
            <p className="text-sm text-gray-400 mt-2">
              {uploadStatus?.remainingUploads || 0} uploads remaining today
            </p>
          </div>
        </Card>

        {/* Recent Uploads Gallery */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Your Recent Uploads</h2>
          {images && images.images.length > 0 ? (
            <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-4">
              {images.images.map((image) => (
                <div
                  key={image.id}
                  className="group relative bg-purple-900/20 border border-purple-900/50 rounded-lg overflow-hidden hover:border-purple-700/50 transition"
                >
                  <img
                    src={image.url}
                    alt={image.fileName}
                    className="w-full h-40 object-cover group-hover:opacity-75 transition"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition flex items-center justify-center">
                    <a
                      href={image.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-purple-400 hover:text-purple-300 text-sm"
                    >
                      View Full
                    </a>
                  </div>
                  <div className="p-2">
                    <p className="text-xs text-gray-400 truncate">{image.fileName}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(image.uploadedAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-purple-900/10 border border-purple-900/30 rounded-lg">
              <ImageIcon className="mx-auto text-purple-500 mb-4" size={48} />
              <p className="text-gray-400 mb-4">No images uploaded yet</p>
              <Button
                onClick={() => setShowUploadModal(true)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                Upload Your First Image
              </Button>
            </div>
          )}
        </div>
      </main>

      {/* Modals */}
      <ImageUploadModal open={showUploadModal} onOpenChange={setShowUploadModal} />
      <AdWatchModal open={showAdModal} onOpenChange={setShowAdModal} />
    </div>
  );
}

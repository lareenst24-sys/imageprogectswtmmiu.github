import { 
  int, 
  mysqlEnum, 
  mysqlTable, 
  text, 
  timestamp, 
  varchar,
  decimal,
  boolean,
  date,
  bigint
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extended with additional fields for image earning platform.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Images uploaded by users
 */
export const images = mysqlTable("images", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileSize: bigint("fileSize", { mode: "number" }).notNull(), // in bytes
  supabaseKey: varchar("supabaseKey", { length: 512 }).notNull(), // path in Supabase storage
  supabaseUrl: text("supabaseUrl").notNull(), // public URL
  mimeType: varchar("mimeType", { length: 100 }).notNull(),
  uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Image = typeof images.$inferSelect;
export type InsertImage = typeof images.$inferInsert;

/**
 * Daily upload limits per user
 * Resets every day at UTC midnight
 */
export const uploadLimits = mysqlTable("uploadLimits", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(), // one per user per day
  date: date("date").notNull(), // YYYY-MM-DD format
  baseLimit: int("baseLimit").default(1000).notNull(), // 1000 images per day
  bonusLimit: int("bonusLimit").default(0).notNull(), // bonus from ad watches
  imagesUploaded: int("imagesUploaded").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UploadLimit = typeof uploadLimits.$inferSelect;
export type InsertUploadLimit = typeof uploadLimits.$inferInsert;

/**
 * Earnings tracking per user
 */
export const earnings = mysqlTable("earnings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(), // in cents or smallest currency unit
  currency: varchar("currency", { length: 3 }).default("USD").notNull(), // ISO 4217 code
  reason: varchar("reason", { length: 100 }).notNull(), // e.g., "image_upload", "bonus"
  imageId: int("imageId"), // reference to image if earnings from upload
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Earning = typeof earnings.$inferSelect;
export type InsertEarning = typeof earnings.$inferInsert;

/**
 * User settings (currency, payout info, etc.)
 */
export const userSettings = mysqlTable("userSettings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  currency: varchar("currency", { length: 3 }).default("USD").notNull(), // ISO 4217 code
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }), // Stripe customer ID
  stripeConnectId: varchar("stripeConnectId", { length: 255 }), // Stripe Connect account ID
  totalEarnings: decimal("totalEarnings", { precision: 12, scale: 2 }).default("0").notNull(),
  totalWithdrawn: decimal("totalWithdrawn", { precision: 12, scale: 2 }).default("0").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserSetting = typeof userSettings.$inferSelect;
export type InsertUserSetting = typeof userSettings.$inferInsert;

/**
 * Ad watch history for tracking bonus limit increases
 */
export const adWatches = mysqlTable("adWatches", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  bonusImagesGranted: int("bonusImagesGranted").default(100).notNull(), // bonus images added to daily limit
  watchedAt: timestamp("watchedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AdWatch = typeof adWatches.$inferSelect;
export type InsertAdWatch = typeof adWatches.$inferInsert;

/**
 * Payment transactions (withdrawals, refunds, etc.)
 */
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }).unique(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(), // in cents or smallest currency unit
  currency: varchar("currency", { length: 3 }).default("USD").notNull(),
  status: mysqlEnum("status", ["pending", "processing", "completed", "failed", "refunded"]).default("pending").notNull(),
  type: mysqlEnum("type", ["withdrawal", "refund", "bonus"]).default("withdrawal").notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

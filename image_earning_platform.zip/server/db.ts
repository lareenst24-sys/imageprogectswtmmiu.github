import { eq, and, gte, desc, lt } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users,
  images,
  uploadLimits,
  earnings,
  userSettings,
  adWatches,
  payments,
  Image,
  UploadLimit,
  Earning,
  UserSetting,
  AdWatch,
  Payment
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Image management
export async function createImage(image: typeof images.$inferInsert): Promise<Image> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(images).values(image);
  const insertedId = result[0].insertId;
  
  const created = await db.select().from(images).where(eq(images.id, insertedId as number)).limit(1);
  return created[0]!;
}

export async function getUserImages(userId: number, limit: number = 20, offset: number = 0): Promise<Image[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select()
    .from(images)
    .where(eq(images.userId, userId))
    .orderBy(desc(images.uploadedAt))
    .limit(limit)
    .offset(offset);
}

export async function getImageCount(userId: number): Promise<number> {
  const db = await getDb();
  if (!db) return 0;

  const result = await db.select().from(images).where(eq(images.userId, userId));
  return result.length;
}

// Upload limits
export async function getOrCreateUploadLimit(userId: number, date: Date | string): Promise<UploadLimit> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const dateStr = typeof date === 'string' ? date : date.toISOString().split('T')[0];

  const existing = await db.select()
    .from(uploadLimits)
    .where(and(eq(uploadLimits.userId, userId), eq(uploadLimits.date, new Date(dateStr))))
    .limit(1);

  if (existing.length > 0) {
    return existing[0]!;
  }

  // Create new limit entry for today
  await db.insert(uploadLimits).values({
    userId,
    date: new Date(dateStr),
    baseLimit: 1000,
    bonusLimit: 0,
    imagesUploaded: 0,
  });

  const created = await db.select()
    .from(uploadLimits)
    .where(and(eq(uploadLimits.userId, userId), eq(uploadLimits.date, new Date(dateStr))))
    .limit(1);

  return created[0]!;
}

export async function incrementUploadCount(userId: number, date: Date | string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const dateStr = typeof date === 'string' ? date : date.toISOString().split('T')[0];
  const limit = await getOrCreateUploadLimit(userId, dateStr);
  
  await db.update(uploadLimits)
    .set({ imagesUploaded: limit.imagesUploaded + 1 })
    .where(and(eq(uploadLimits.userId, userId), eq(uploadLimits.date, new Date(dateStr))));
}

export async function addBonusLimit(userId: number, date: Date | string, bonusImages: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const dateStr = typeof date === 'string' ? date : date.toISOString().split('T')[0];
  const limit = await getOrCreateUploadLimit(userId, dateStr);
  
  await db.update(uploadLimits)
    .set({ bonusLimit: limit.bonusLimit + bonusImages })
    .where(and(eq(uploadLimits.userId, userId), eq(uploadLimits.date, new Date(dateStr))));
}

// Earnings
export async function createEarning(earning: typeof earnings.$inferInsert): Promise<Earning> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(earnings).values(earning);
  const insertedId = result[0].insertId;

  const created = await db.select().from(earnings).where(eq(earnings.id, insertedId as number)).limit(1);
  return created[0]!;
}

export async function getUserEarnings(userId: number): Promise<Earning[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select()
    .from(earnings)
    .where(eq(earnings.userId, userId))
    .orderBy(desc(earnings.createdAt));
}

export async function getTotalEarnings(userId: number): Promise<number> {
  const db = await getDb();
  if (!db) return 0;

  const result = await db.select({ total: earnings.amount })
    .from(earnings)
    .where(eq(earnings.userId, userId));

  return result.reduce((sum, row) => sum + parseFloat(row.total as any), 0);
}

// User settings
export async function getOrCreateUserSettings(userId: number): Promise<UserSetting> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await db.select()
    .from(userSettings)
    .where(eq(userSettings.userId, userId))
    .limit(1);

  if (existing.length > 0) {
    return existing[0]!;
  }

  // Create new settings
  await db.insert(userSettings).values({
    userId,
    currency: "USD",
    totalEarnings: "0",
    totalWithdrawn: "0",
  });

  const created = await db.select()
    .from(userSettings)
    .where(eq(userSettings.userId, userId))
    .limit(1);

  return created[0]!;
}

export async function updateUserSettings(userId: number, updates: Partial<UserSetting>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(userSettings)
    .set(updates)
    .where(eq(userSettings.userId, userId));
}

// Ad watches
export async function createAdWatch(userId: number, bonusImages: number = 100): Promise<AdWatch> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(adWatches).values({
    userId,
    bonusImagesGranted: bonusImages,
  });

  const insertedId = result[0].insertId;

  const created = await db.select()
    .from(adWatches)
    .where(eq(adWatches.id, insertedId as number))
    .limit(1);

  return created[0]!;
}

export async function getUserAdWatches(userId: number): Promise<AdWatch[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select()
    .from(adWatches)
    .where(eq(adWatches.userId, userId))
    .orderBy(desc(adWatches.watchedAt));
}

// Payments
export async function createPayment(payment: typeof payments.$inferInsert): Promise<Payment> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(payments).values(payment);
  const insertedId = result[0].insertId;

  const created = await db.select()
    .from(payments)
    .where(eq(payments.id, insertedId as number))
    .limit(1);

  return created[0]!;
}

export async function getPaymentByStripeId(stripePaymentIntentId: string): Promise<Payment | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select()
    .from(payments)
    .where(eq(payments.stripePaymentIntentId, stripePaymentIntentId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function updatePaymentStatus(paymentId: number, status: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(payments)
    .set({ status: status as any })
    .where(eq(payments.id, paymentId));
}

export async function getUserPayments(userId: number): Promise<Payment[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select()
    .from(payments)
    .where(eq(payments.userId, userId))
    .orderBy(desc(payments.createdAt));
}

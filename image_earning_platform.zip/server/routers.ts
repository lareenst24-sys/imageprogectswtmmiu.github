import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import {
  createImage,
  getUserImages,
  getImageCount,
  getOrCreateUploadLimit,
  incrementUploadCount,
  addBonusLimit,
  createEarning,
  getUserEarnings,
  getTotalEarnings,
  getOrCreateUserSettings,
  updateUserSettings,
  createAdWatch,
  getUserAdWatches,
  createPayment,
  getPaymentByStripeId,
  updatePaymentStatus,
  getUserPayments,
  getUserById,
} from "./db";
import { storagePut, storageGet } from "./storage";
import { nanoid } from "nanoid";

const EARNINGS_PER_IMAGE = 0.01; // $0.01 per image
const MAX_AD_WATCHES_PER_DAY = 10;
const BONUS_IMAGES_PER_AD = 100;

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Image management
  images: router({
    // Upload image
    upload: protectedProcedure
      .input(z.object({
        fileName: z.string().min(1),
        fileData: z.instanceof(Buffer),
        mimeType: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const userId = ctx.user.id;
        const today = new Date().toISOString().split('T')[0];

        // Check upload limit
        const uploadLimit = await getOrCreateUploadLimit(userId, today);
        const totalLimit = uploadLimit.baseLimit + uploadLimit.bonusLimit;

        if (uploadLimit.imagesUploaded >= totalLimit) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: `Daily upload limit reached. You have uploaded ${uploadLimit.imagesUploaded}/${totalLimit} images today.`,
          });
        }

        // Validate file size (max 50MB)
        const maxFileSize = 50 * 1024 * 1024;
        if (input.fileData.length > maxFileSize) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "File size exceeds 50MB limit",
          });
        }

        // Upload to Supabase/S3
        const fileKey = `images/${userId}/${nanoid()}-${input.fileName}`;
        const { url } = await storagePut(fileKey, input.fileData, input.mimeType);

        // Create image record
        const image = await createImage({
          userId,
          fileName: input.fileName,
          fileSize: input.fileData.length,
          supabaseKey: fileKey,
          supabaseUrl: url,
          mimeType: input.mimeType,
        })

        // Increment upload count
        await incrementUploadCount(userId, today);

        // Award earnings
        await createEarning({
          userId,
          amount: EARNINGS_PER_IMAGE.toString(),
          currency: "USD",
          reason: "image_upload",
          imageId: image.id,
        });

        // Update user total earnings
        const settings = await getOrCreateUserSettings(userId);
        const newTotal = (parseFloat(settings.totalEarnings as any) + EARNINGS_PER_IMAGE).toFixed(2);
        await updateUserSettings(userId, { totalEarnings: newTotal });

        return {
          success: true,
          image: {
            id: image.id,
            url: image.supabaseUrl,
            fileName: image.fileName,
          },
        };
      }),

    // Get user's images with pagination
    list: protectedProcedure
      .input(z.object({
        limit: z.number().min(1).max(100).default(20),
        offset: z.number().min(0).default(0),
      }))
      .query(async ({ ctx, input }) => {
        const images = await getUserImages(ctx.user.id, input.limit, input.offset);
        const totalCount = await getImageCount(ctx.user.id);

        return {
          images: images.map(img => ({
            id: img.id,
            fileName: img.fileName,
            url: img.supabaseUrl,
            uploadedAt: img.uploadedAt,
          })),
          totalCount,
          hasMore: input.offset + input.limit < totalCount,
        };
      }),

    // Get image count
    count: protectedProcedure.query(async ({ ctx }) => {
      return await getImageCount(ctx.user.id);
    }),
  }),

  // Upload limits
  uploadLimit: router({
    // Get current upload limit status
    status: protectedProcedure.query(async ({ ctx }) => {
      const today = new Date().toISOString().split('T')[0];
      const limit = await getOrCreateUploadLimit(ctx.user.id, today);

      return {
        baseLimit: limit.baseLimit,
        bonusLimit: limit.bonusLimit,
        totalLimit: limit.baseLimit + limit.bonusLimit,
        imagesUploaded: limit.imagesUploaded,
        remainingUploads: (limit.baseLimit + limit.bonusLimit) - limit.imagesUploaded,
      };
    }),
  }),

  // Earnings
  earnings: router({
    // Get user earnings
    list: protectedProcedure
      .input(z.object({
        limit: z.number().min(1).max(100).default(20),
        offset: z.number().min(0).default(0),
      }))
      .query(async ({ ctx, input }) => {
        const earnings = await getUserEarnings(ctx.user.id);
        const sliced = earnings.slice(input.offset, input.offset + input.limit);

        return {
          earnings: sliced.map(e => ({
            id: e.id,
            amount: parseFloat(e.amount as any),
            currency: e.currency,
            reason: e.reason,
            createdAt: e.createdAt,
          })),
          totalCount: earnings.length,
        };
      }),

    // Get total earnings
    total: protectedProcedure.query(async ({ ctx }) => {
      const settings = await getOrCreateUserSettings(ctx.user.id);
      return {
        total: parseFloat(settings.totalEarnings as any),
        withdrawn: parseFloat(settings.totalWithdrawn as any),
        available: parseFloat(settings.totalEarnings as any) - parseFloat(settings.totalWithdrawn as any),
        currency: settings.currency,
      };
    }),
  }),

  // Ad watches
  adWatch: router({
    // Watch an ad and get bonus uploads
    watch: protectedProcedure.mutation(async ({ ctx }) => {
      const userId = ctx.user.id;
      const today = new Date().toISOString().split('T')[0];

      // Check how many ads watched today
      const adWatches = await getUserAdWatches(userId);
      const watchesToday = adWatches.filter(aw => {
        const watchDate = new Date(aw.watchedAt).toISOString().split('T')[0];
        return watchDate === today;
      }).length;

      if (watchesToday >= MAX_AD_WATCHES_PER_DAY) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: `You can watch a maximum of ${MAX_AD_WATCHES_PER_DAY} ads per day`,
        });
      }

      // Create ad watch record
      const adWatch = await createAdWatch(userId, BONUS_IMAGES_PER_AD);

      // Add bonus to today's limit
      await addBonusLimit(userId, today, BONUS_IMAGES_PER_AD);

      return {
        success: true,
        bonusImagesGranted: BONUS_IMAGES_PER_AD,
        message: `You've earned ${BONUS_IMAGES_PER_AD} bonus image uploads!`,
      };
    }),

    // Get ad watch history
    history: protectedProcedure
      .input(z.object({
        limit: z.number().min(1).max(100).default(20),
        offset: z.number().min(0).default(0),
      }))
      .query(async ({ ctx, input }) => {
        const adWatches = await getUserAdWatches(ctx.user.id);
        const sliced = adWatches.slice(input.offset, input.offset + input.limit);

        return {
          adWatches: sliced.map(aw => ({
            id: aw.id,
            bonusImagesGranted: aw.bonusImagesGranted,
            watchedAt: aw.watchedAt,
          })),
          totalCount: adWatches.length,
        };
      }),

    // Get remaining ad watches for today
    remainingToday: protectedProcedure.query(async ({ ctx }) => {
      const userId = ctx.user.id;
      const today = new Date().toISOString().split('T')[0];

      const adWatches = await getUserAdWatches(userId);
      const watchesToday = adWatches.filter(aw => {
        const watchDate = new Date(aw.watchedAt).toISOString().split('T')[0];
        return watchDate === today;
      }).length;

      return {
        remaining: Math.max(0, MAX_AD_WATCHES_PER_DAY - watchesToday),
        maxPerDay: MAX_AD_WATCHES_PER_DAY,
      };
    }),
  }),

  // User settings
  settings: router({
    // Get user settings
    get: protectedProcedure.query(async ({ ctx }) => {
      const settings = await getOrCreateUserSettings(ctx.user.id);
      const user = await getUserById(ctx.user.id);

      return {
        currency: settings.currency,
        stripeCustomerId: settings.stripeCustomerId,
        totalEarnings: parseFloat(settings.totalEarnings as any),
        totalWithdrawn: parseFloat(settings.totalWithdrawn as any),
        email: user?.email,
        name: user?.name,
      };
    }),

    // Update currency
    updateCurrency: protectedProcedure
      .input(z.object({
        currency: z.string().length(3).toUpperCase(),
      }))
      .mutation(async ({ ctx, input }) => {
        await updateUserSettings(ctx.user.id, { currency: input.currency });
        return { success: true };
      }),

    // Update Stripe customer ID
    updateStripeCustomer: protectedProcedure
      .input(z.object({
        stripeCustomerId: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        await updateUserSettings(ctx.user.id, { stripeCustomerId: input.stripeCustomerId });
        return { success: true };
      }),
  }),

  // Payments
  payments: router({
    // Create withdrawal payment
    createWithdrawal: protectedProcedure
      .input(z.object({
        amount: z.number().positive(),
        stripePaymentMethodId: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const settings = await getOrCreateUserSettings(ctx.user.id);
        const available = parseFloat(settings.totalEarnings as any) - parseFloat(settings.totalWithdrawn as any);

        if (input.amount > available) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Insufficient funds for withdrawal",
          });
        }

        // Create payment record
        const payment = await createPayment({
          userId: ctx.user.id,
          amount: input.amount.toString(),
          currency: settings.currency,
          status: "pending",
          type: "withdrawal",
          description: `Withdrawal of ${input.amount} ${settings.currency}`,
        });

        // TODO: Integrate with Stripe to process payment
        // For now, just return success

        return {
          success: true,
          paymentId: payment.id,
          amount: input.amount,
          currency: settings.currency,
        };
      }),

    // Get user payments
    list: protectedProcedure
      .input(z.object({
        limit: z.number().min(1).max(100).default(20),
        offset: z.number().min(0).default(0),
      }))
      .query(async ({ ctx, input }) => {
        const payments = await getUserPayments(ctx.user.id);
        const sliced = payments.slice(input.offset, input.offset + input.limit);

        return {
          payments: sliced.map(p => ({
            id: p.id,
            amount: parseFloat(p.amount as any),
            currency: p.currency,
            status: p.status,
            type: p.type,
            createdAt: p.createdAt,
          })),
          totalCount: payments.length,
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
